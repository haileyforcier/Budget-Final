﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Budget_App_Final
{
    internal class Expenditure
    {
        public String ExpenditureName { get; set; }
        public String Amount { get; set; }
        public String Note { get; set; }



        // override the default ToString() function to provide 
        // a formatted representation of the expenditure
        public override String ToString()
        {
            return ExpenditureName + " - $" + Amount.ToString("C");
        }
    }
}
