﻿namespace Budget_App_Final
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txtCategoryName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtStartBalance = new System.Windows.Forms.TextBox();
            this.btnCreateCategory = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lbxCategories = new System.Windows.Forms.ListBox();
            this.gbxNewCategory = new System.Windows.Forms.GroupBox();
            this.btnDeleteCategory = new System.Windows.Forms.Button();
            this.gbxSelectedCategory = new System.Windows.Forms.GroupBox();
            this.btnDeleteExpend = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.lbxExpenditures = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.prbBalance = new System.Windows.Forms.ProgressBar();
            this.txtDispCurrentBalance = new System.Windows.Forms.TextBox();
            this.txtDispStartBalance = new System.Windows.Forms.TextBox();
            this.txtDispCategoryName = new System.Windows.Forms.TextBox();
            this.gbxAddExpenditure = new System.Windows.Forms.GroupBox();
            this.btnAddExpend = new System.Windows.Forms.Button();
            this.txtExpendNotes = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtExpendAmount = new System.Windows.Forms.TextBox();
            this.txtExpendName = new System.Windows.Forms.TextBox();
            this.btnClearExpend = new System.Windows.Forms.Button();
            this.gbxNewCategory.SuspendLayout();
            this.gbxSelectedCategory.SuspendLayout();
            this.gbxAddExpenditure.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Category Name:";
            // 
            // txtCategoryName
            // 
            this.txtCategoryName.Location = new System.Drawing.Point(105, 24);
            this.txtCategoryName.Name = "txtCategoryName";
            this.txtCategoryName.Size = new System.Drawing.Size(100, 23);
            this.txtCategoryName.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Starting Balance:";
            // 
            // txtStartBalance
            // 
            this.txtStartBalance.Location = new System.Drawing.Point(105, 53);
            this.txtStartBalance.Name = "txtStartBalance";
            this.txtStartBalance.Size = new System.Drawing.Size(100, 23);
            this.txtStartBalance.TabIndex = 4;
            // 
            // btnCreateCategory
            // 
            this.btnCreateCategory.Location = new System.Drawing.Point(6, 82);
            this.btnCreateCategory.Name = "btnCreateCategory";
            this.btnCreateCategory.Size = new System.Drawing.Size(199, 23);
            this.btnCreateCategory.TabIndex = 5;
            this.btnCreateCategory.Text = "Create Category";
            this.btnCreateCategory.UseVisualStyleBackColor = true;
            this.btnCreateCategory.Click += new System.EventHandler(this.btnCreateCategory_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Budget Categories";
            // 
            // lbxCategories
            // 
            this.lbxCategories.FormattingEnabled = true;
            this.lbxCategories.ItemHeight = 15;
            this.lbxCategories.Location = new System.Drawing.Point(6, 146);
            this.lbxCategories.Name = "lbxCategories";
            this.lbxCategories.Size = new System.Drawing.Size(199, 259);
            this.lbxCategories.TabIndex = 7;
            this.lbxCategories.SelectedIndexChanged += new System.EventHandler(this.lbxCategories_SelectedIndexChanged);
            // 
            // gbxNewCategory
            // 
            this.gbxNewCategory.Controls.Add(this.btnDeleteCategory);
            this.gbxNewCategory.Controls.Add(this.lbxCategories);
            this.gbxNewCategory.Controls.Add(this.label2);
            this.gbxNewCategory.Controls.Add(this.label4);
            this.gbxNewCategory.Controls.Add(this.txtCategoryName);
            this.gbxNewCategory.Controls.Add(this.btnCreateCategory);
            this.gbxNewCategory.Controls.Add(this.label3);
            this.gbxNewCategory.Controls.Add(this.txtStartBalance);
            this.gbxNewCategory.Location = new System.Drawing.Point(12, 12);
            this.gbxNewCategory.Name = "gbxNewCategory";
            this.gbxNewCategory.Size = new System.Drawing.Size(213, 447);
            this.gbxNewCategory.TabIndex = 8;
            this.gbxNewCategory.TabStop = false;
            this.gbxNewCategory.Text = "Create Budget Category";
            // 
            // btnDeleteCategory
            // 
            this.btnDeleteCategory.Location = new System.Drawing.Point(6, 411);
            this.btnDeleteCategory.Name = "btnDeleteCategory";
            this.btnDeleteCategory.Size = new System.Drawing.Size(199, 23);
            this.btnDeleteCategory.TabIndex = 8;
            this.btnDeleteCategory.Text = "Delete Category";
            this.btnDeleteCategory.UseVisualStyleBackColor = true;
            this.btnDeleteCategory.Click += new System.EventHandler(this.btnDeleteCategory_Click);
            // 
            // gbxSelectedCategory
            // 
            this.gbxSelectedCategory.Controls.Add(this.btnDeleteExpend);
            this.gbxSelectedCategory.Controls.Add(this.label7);
            this.gbxSelectedCategory.Controls.Add(this.lbxExpenditures);
            this.gbxSelectedCategory.Controls.Add(this.label6);
            this.gbxSelectedCategory.Controls.Add(this.label5);
            this.gbxSelectedCategory.Controls.Add(this.label1);
            this.gbxSelectedCategory.Controls.Add(this.prbBalance);
            this.gbxSelectedCategory.Controls.Add(this.txtDispCurrentBalance);
            this.gbxSelectedCategory.Controls.Add(this.txtDispStartBalance);
            this.gbxSelectedCategory.Controls.Add(this.txtDispCategoryName);
            this.gbxSelectedCategory.Location = new System.Drawing.Point(231, 12);
            this.gbxSelectedCategory.Name = "gbxSelectedCategory";
            this.gbxSelectedCategory.Size = new System.Drawing.Size(213, 447);
            this.gbxSelectedCategory.TabIndex = 9;
            this.gbxSelectedCategory.TabStop = false;
            this.gbxSelectedCategory.Text = "Selected Category";
            // 
            // btnDeleteExpend
            // 
            this.btnDeleteExpend.Location = new System.Drawing.Point(6, 411);
            this.btnDeleteExpend.Name = "btnDeleteExpend";
            this.btnDeleteExpend.Size = new System.Drawing.Size(199, 23);
            this.btnDeleteExpend.TabIndex = 9;
            this.btnDeleteExpend.Text = "Delete Expenditure";
            this.btnDeleteExpend.UseVisualStyleBackColor = true;
            this.btnDeleteExpend.Click += new System.EventHandler(this.btnDeleteExpend_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 128);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "Expenditures";
            // 
            // lbxExpenditures
            // 
            this.lbxExpenditures.FormattingEnabled = true;
            this.lbxExpenditures.ItemHeight = 15;
            this.lbxExpenditures.Location = new System.Drawing.Point(6, 146);
            this.lbxExpenditures.Name = "lbxExpenditures";
            this.lbxExpenditures.Size = new System.Drawing.Size(199, 259);
            this.lbxExpenditures.TabIndex = 8;
            this.lbxExpenditures.SelectedIndexChanged += new System.EventHandler(this.lbxExpenditures_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Current Balance:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Starting Balance:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 12;
            this.label1.Text = "Name:";
            // 
            // prbBalance
            // 
            this.prbBalance.Location = new System.Drawing.Point(107, 114);
            this.prbBalance.Name = "prbBalance";
            this.prbBalance.Size = new System.Drawing.Size(100, 23);
            this.prbBalance.TabIndex = 11;
            // 
            // txtDispCurrentBalance
            // 
            this.txtDispCurrentBalance.Enabled = false;
            this.txtDispCurrentBalance.Location = new System.Drawing.Point(107, 85);
            this.txtDispCurrentBalance.Name = "txtDispCurrentBalance";
            this.txtDispCurrentBalance.Size = new System.Drawing.Size(100, 23);
            this.txtDispCurrentBalance.TabIndex = 10;
            // 
            // txtDispStartBalance
            // 
            this.txtDispStartBalance.Enabled = false;
            this.txtDispStartBalance.Location = new System.Drawing.Point(107, 56);
            this.txtDispStartBalance.Name = "txtDispStartBalance";
            this.txtDispStartBalance.Size = new System.Drawing.Size(100, 23);
            this.txtDispStartBalance.TabIndex = 9;
            // 
            // txtDispCategoryName
            // 
            this.txtDispCategoryName.Enabled = false;
            this.txtDispCategoryName.Location = new System.Drawing.Point(107, 27);
            this.txtDispCategoryName.Name = "txtDispCategoryName";
            this.txtDispCategoryName.Size = new System.Drawing.Size(100, 23);
            this.txtDispCategoryName.TabIndex = 8;
            // 
            // gbxAddExpenditure
            // 
            this.gbxAddExpenditure.Controls.Add(this.btnClearExpend);
            this.gbxAddExpenditure.Controls.Add(this.btnAddExpend);
            this.gbxAddExpenditure.Controls.Add(this.txtExpendNotes);
            this.gbxAddExpenditure.Controls.Add(this.label8);
            this.gbxAddExpenditure.Controls.Add(this.label10);
            this.gbxAddExpenditure.Controls.Add(this.label11);
            this.gbxAddExpenditure.Controls.Add(this.txtExpendAmount);
            this.gbxAddExpenditure.Controls.Add(this.txtExpendName);
            this.gbxAddExpenditure.Location = new System.Drawing.Point(450, 12);
            this.gbxAddExpenditure.Name = "gbxAddExpenditure";
            this.gbxAddExpenditure.Size = new System.Drawing.Size(213, 447);
            this.gbxAddExpenditure.TabIndex = 13;
            this.gbxAddExpenditure.TabStop = false;
            this.gbxAddExpenditure.Text = "Add Expenditure";
            // 
            // btnAddExpend
            // 
            this.btnAddExpend.Location = new System.Drawing.Point(6, 411);
            this.btnAddExpend.Name = "btnAddExpend";
            this.btnAddExpend.Size = new System.Drawing.Size(199, 23);
            this.btnAddExpend.TabIndex = 13;
            this.btnAddExpend.Text = "Add Expenditure";
            this.btnAddExpend.UseVisualStyleBackColor = true;
            this.btnAddExpend.Click += new System.EventHandler(this.btnAddExpend_Click);
            // 
            // txtExpendNotes
            // 
            this.txtExpendNotes.Location = new System.Drawing.Point(7, 146);
            this.txtExpendNotes.Multiline = true;
            this.txtExpendNotes.Name = "txtExpendNotes";
            this.txtExpendNotes.Size = new System.Drawing.Size(200, 259);
            this.txtExpendNotes.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 15);
            this.label8.TabIndex = 10;
            this.label8.Text = "Expenditure Notes";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(47, 83);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 15);
            this.label10.TabIndex = 10;
            this.label10.Text = "Amount:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 54);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 15);
            this.label11.TabIndex = 12;
            this.label11.Text = "Expend. Name:";
            // 
            // txtExpendAmount
            // 
            this.txtExpendAmount.Location = new System.Drawing.Point(107, 80);
            this.txtExpendAmount.Name = "txtExpendAmount";
            this.txtExpendAmount.Size = new System.Drawing.Size(100, 23);
            this.txtExpendAmount.TabIndex = 9;
            // 
            // txtExpendName
            // 
            this.txtExpendName.Location = new System.Drawing.Point(107, 51);
            this.txtExpendName.Name = "txtExpendName";
            this.txtExpendName.Size = new System.Drawing.Size(100, 23);
            this.txtExpendName.TabIndex = 8;
            // 
            // btnClearExpend
            // 
            this.btnClearExpend.Location = new System.Drawing.Point(107, 19);
            this.btnClearExpend.Name = "btnClearExpend";
            this.btnClearExpend.Size = new System.Drawing.Size(98, 23);
            this.btnClearExpend.TabIndex = 14;
            this.btnClearExpend.Text = "Clear Fields";
            this.btnClearExpend.UseVisualStyleBackColor = true;
            this.btnClearExpend.Click += new System.EventHandler(this.btnClearExpend_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 469);
            this.Controls.Add(this.gbxAddExpenditure);
            this.Controls.Add(this.gbxSelectedCategory);
            this.Controls.Add(this.gbxNewCategory);
            this.Name = "Form1";
            this.Text = "Budget App V. 1.0";
            this.gbxNewCategory.ResumeLayout(false);
            this.gbxNewCategory.PerformLayout();
            this.gbxSelectedCategory.ResumeLayout(false);
            this.gbxSelectedCategory.PerformLayout();
            this.gbxAddExpenditure.ResumeLayout(false);
            this.gbxAddExpenditure.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Label label2;
        private TextBox txtCategoryName;
        private Label label3;
        private TextBox txtStartBalance;
        private Button btnCreateCategory;
        private Label label4;
        private ListBox lbxCategories;
        private GroupBox gbxNewCategory;
        private Button btnDeleteCategory;
        private GroupBox gbxSelectedCategory;
        private Button btnDeleteExpend;
        private Label label7;
        private ListBox lbxExpenditures;
        private Label label6;
        private Label label5;
        private Label label1;
        private ProgressBar prbBalance;
        private TextBox txtDispCurrentBalance;
        private TextBox txtDispStartBalance;
        private TextBox txtDispCategoryName;
        private GroupBox gbxAddExpenditure;
        private Button btnAddExpend;
        private TextBox txtExpendNotes;
        private Label label8;
        private Label label10;
        private Label label11;
        private TextBox txtExpendAmount;
        private TextBox txtExpendName;
        private Button btnClearExpend;
    }
}