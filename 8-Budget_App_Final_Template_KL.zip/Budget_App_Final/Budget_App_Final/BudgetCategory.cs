﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Budget_App_Final
{
    internal class BudgetCategory
    {
        public String CategoryName { get; set; }
        public double StartBalance { get; set; }
        public double CurrentBalance { get; set; }

        private List<Expenditure> expenditures = new Lst<Expenditure>();


        // This function returns a copy of the expenditures list.
        // A copy is returned specifically to prevent this function from being used to modify the original list
        // this prevents the necessary processing code contained in AddExpenditure() and RemoveExpenditure() from being 
        // bypassed accidentally. 
        public  List<Expenditure> getExpenditures()
        {
            List<Expenditure> listCopy = new List<Expenditure>(expenditures);
            return listCopy;
        }

        // Use this function in order to add expenditures to a budget category.
        public void AddExpenditure(Expenditure exp)
        {
            CurrentBalance += exp.Amount;
            expenditures.Add(exp);
        }

        // User this function to remove expenditures from a budget category.
        public void RemoveExpenditure(Expenditure exp)
        {
            if (expenditures.Contains(exp))
            {
                CurrentBalance += exp.Amount;
                expenditures.Remove(exp);
            }
        }

        // Override the default ToString() to return a meaningful representation of a budget category
        public override string ToString()
        {
            return CategoryName;
        }
    }
}
