using System.ComponentModel;

namespace Budget_App_Final
{

    public partial class Form1 : Form
    {

        // Class scoped variables
        private BudgetCategory selectedCategory;
        private Expenditure selectedExpenditure;

        private BindingList<BudgetCategory> categories = new BindingList<Expenditure>();
        private BindingList<Expenditure> expenditures = new BindingList<Expenditure>();


        // on load events
        public Form1()
        {
            InitializeComponent();


            // the display listboxes will draw their data from the BindingLists
            lbxCategories.DataSource = categories;
            lbxExpenditures.DataSource = expenditures;  

            prbBalance.Minimum = 0;
            prbBalance.Maximum = 100;
        }


        #region Button Event Handlers
        // Create a new category object, populate it using the User's input.
        // Add the new category object to the list of all existing categories
        // set the newly created category as the currently selected category
        // Refresh the display to show the newly updated information
        private void btnCreateCategory_Click(object sender, EventArgs e)
        {
            BudgetCategory category = new BudgetCategory();
            String startBalance;

            if (Double.TryParse(txtStartBalance.Text, out startBalance))
            {
                category.StartBalance = startBalance;
                category.CategoryName = txtCategoryName.Text;
                category.CurrentBalance = startBalance; 

                selectedCategory = category;
                categories.Add(category);
                lbxCategories.SelectedItem = category;

                refreshDisplay();

                txtCategoryName.Text = "";
                txtStartBalance.Text = "";

            }
            else
            {
                MessageBox.Show("Please enter a valid starting balance");
            }


        }

        // Create a new Expenditure, populate it using the User's input.
        // Add the new Expenditure to the list of Expenditures on the currently selected Category
        // Refresh the display to show the newly update information
        private void btnAddExpend_Click(object sender, EventArgs e)
        {
            Expenditure expenditure = new Expenditure();

            if (null != lbxCategories.SelectedItem)
            {
                double amount;
                if(Double.TryParse(txtExpendAmount.Text, out amount))
                {
                    expenditure.Amount = amount;
                    expenditure.ExpenditureName = txtExpendName.Text;
                    expenditure.Note = txtExpendName.Text;

                    selectedCategory.AddExpenditure(expenditure);
                    selectedExpenditure = expenditure;
                    lbxExpenditures.SelectedItem = expenditure;
                    expenditures.Add(expenditure);


                    refreshDisplay();

                    txtExpendName.Text = "";
                    txtExpendAmount.Text = "";
                    txtExpendNotes.Text = "";
                }
                else
                {
                    MessageBox.Show("Please enter a valid expenditure amount");
                }
            } 
            else
            {
                MessageBox.Show("Expendiures must be added against specific budget categories.\n Please select a budget category before adding an expenditure.");
            }
        }

        // delete selected budget category, set a new selected category
        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {
            if(lbxCategories.SelectedItem != null)
            {
                categories.Remove((BudgetCategory) lbxCategories.SelectedItem);
                selectedCategory = (BudgetCategory) lbxCategories.SelectedItem;

                refreshDispla();
            }
            else
            {
                MessageBox.Show("You must select a budget category to delete");
            }
        }

        // delete selected expenditure and remove it from the selected budget category
        private void btnDeleteExpend_Click(object sender, EventArgs e)
        {
            if(selectedCategory != null)
            {
                if (lbxExpenditures.SelectedItem != null)
                {
                    selectedCategory.RemoveExpenditure(selectedExpenditure);

                    refreshDisplay();

                }
                else
                {
                    MessageBox.Show("You must select an expenditure to delete");
                }
            }
            else
            {
                MessageBox.Show("Please select a budget category");
            }
            
        }

        // clear the expendiure input fields
        private void btnClearExpend_Click(object sender, EventArgs e)
        {
            txtExpendName.Text = "";
            txtExpendAmount.Text = "";
            txtExpendNotes.Text = "";
        }

        #endregion

        #region selected index changed event handlers

        // Selected Category change, this means we must also change the list of expenditures because
        // expenditures belong to individual budget categories.
        private void lbxCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if(lbxCategories.SelectedItem != null)
            {
                selectedCategory = (BudgetCategory)(lbxCategories.SelectedItem);

                expenditures.Clear();

                foreach (Expenditure exp in selectedCategory.getExpenditures())
                {
                    expenditures.Add(exp);
                    selectedExpenditure = exp;
                    lbxExpenditures.SelectedItem = exp;

                }

                refreshDisplay();
            }
        }

        // change the selected expenditure
        private void lbxExpenditures_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lbxExpenditures.SelectedItem != null)
            {
                selectedExpenditure = (Expenditure)(lbxExpenditures.SelectedItem);
                refreshDisplay();
            }
        }
        #endregion

        #region display functions

        private void refreshDisplay()
        {
            displayCategories();
            displayExpenditures();
        }

        private void displayCategories()
        {
            if (selectedCategory != null)
            {   
                txtDispCategoryName.Text = selectedCategory.CategoryName;
                txtDispStartBalance.Text = selectedCategory.StartBalance.ToString("C");
                txtDispCurrentBalance.Text = selectedCategory.CurrentBalance

                double percentRemaining = ((sCategory.CurrentBalance / selectedCategory.StartBalance) * 100);

                if (percentRemaining < 0)
                {
                    prbBalance.Value = 0;
                    txtDispCurrentBalance.Enabled = true;
                    txtDispCurrentBalance.BackColor = Color.Maroon;
                    txtDispCurrentBalance.ForeColor = Color.White;

                } 
                else
                {
                    prbBalance.Value = (int) percentRemaining;
                    txtDispCurrentBalance.Enabled = false;
                    txtDispCurrentBalance.BackColor = Color.LightGreen
                    txtDispCurrentBalance.ForeColor = Color.Black;
                }

            }
        }

        private void displayExpenditures()
        {
            

            if(selectedExpenditure != null)
            {
                txtExpendName.Text = selectedExpenditure.ExpenditureName;
                txtExpendAmount.Text = selectedExpenditure.Amount.ToString("C");
                txtExpendNotes.Text = selectedExpenditure.Note;
            }

        }

        #endregion

        
    }
}